<?php return array('dependencies' => array('wc-components', 'wp-components', 'wp-element'), 'version' => '092d36684bd43b3c307d');
