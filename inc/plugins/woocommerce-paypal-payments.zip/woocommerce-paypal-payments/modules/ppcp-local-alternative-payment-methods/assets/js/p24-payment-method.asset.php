<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry'), 'version' => '297ff471aebc9cd7eb1c');
}
