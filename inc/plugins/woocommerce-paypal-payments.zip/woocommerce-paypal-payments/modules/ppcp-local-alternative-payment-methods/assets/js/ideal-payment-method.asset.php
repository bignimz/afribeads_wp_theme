<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry'), 'version' => 'f3c58d975636da214b38');
}
