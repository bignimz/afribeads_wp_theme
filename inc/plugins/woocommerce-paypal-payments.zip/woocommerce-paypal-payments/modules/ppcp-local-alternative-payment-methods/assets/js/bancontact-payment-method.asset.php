<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry'), 'version' => '9698af62950ce9894982');
}
