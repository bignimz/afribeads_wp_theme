<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry'), 'version' => '37b4139c77bd8899de78');
}
