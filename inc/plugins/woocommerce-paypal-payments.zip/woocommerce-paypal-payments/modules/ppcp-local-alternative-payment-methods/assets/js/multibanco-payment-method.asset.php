<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry'), 'version' => 'b3d37828ba91ea1ce7e0');
}
