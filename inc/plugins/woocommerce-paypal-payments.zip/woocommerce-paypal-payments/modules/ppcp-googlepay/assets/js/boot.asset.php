<?php

namespace {
    return array('dependencies' => array(), 'version' => '1c4118ba23da5a5fc998');
}
