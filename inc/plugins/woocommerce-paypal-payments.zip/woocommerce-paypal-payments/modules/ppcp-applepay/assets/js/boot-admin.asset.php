<?php

namespace {
    return array('dependencies' => array(), 'version' => '7ae09acdda147a38f2a1');
}
