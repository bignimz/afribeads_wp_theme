<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry', 'wp-element', 'wp-i18n'), 'version' => '80168ce39c69968dc845');
}
