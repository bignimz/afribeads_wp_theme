<?php

namespace {
    return array('dependencies' => array(), 'version' => 'd0a5c5105160cd659479');
}
