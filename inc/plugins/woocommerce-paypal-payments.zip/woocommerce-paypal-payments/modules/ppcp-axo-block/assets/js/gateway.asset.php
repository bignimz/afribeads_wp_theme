<?php

namespace {
    return array('dependencies' => array(), 'version' => '674f3fd433119e2bbdc1');
}
