<?php

/**
 * The Axo module.
 *
 * @package WooCommerce\PayPalCommerce\Axo
 */
declare (strict_types=1);
namespace WooCommerce\PayPalCommerce\Axo;

return static function (): \WooCommerce\PayPalCommerce\Axo\AxoModule {
    return new \WooCommerce\PayPalCommerce\Axo\AxoModule();
};
